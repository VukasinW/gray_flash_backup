const { app, BrowserWindow } = require('electron');

app.on('ready', () => {
    const window = new BrowserWindow({
        width: 50,
        height: 200,
        autoHideMenuBar: true,
        alwaysOnTop: true
    });
    window.loadFile(`${__dirname}\\www\\enderman.html`);
});