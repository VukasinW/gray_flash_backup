const open = require('open');

open(`file://${__dirname}/page/index.html`);