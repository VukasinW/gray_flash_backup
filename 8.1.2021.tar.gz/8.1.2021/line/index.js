console = require('./fancy_console');

async function loadDisk() {
    return new Promise((resolve, reject) => {
        const loader = new console.ProgressBar();
        const labels = {
            0: 'Downloading metadata',
            10: '<green><b>Parsing metadata',
            18: 'Configuring system files',
            24: 'Writing data to disk',
            77: '<blue><b>Indexing disk',
            80: '<red><b>Checking for errors',
            89: 'Running post-install script',
            90: 'Closing the file',
            100: 'Finished.'
        }
        console.log('Installing some file...');
        setInterval((() => {
            let i = 0;
            return function() {
                if(Math.random()*100 > 60 || Math.random()*100 < 10)
                    return;
                loader.update(i, labels[i]);
                if(i++ > 99) {
                    clearInterval(this);
                    loader.finish();
                    const successful = [true, true, false, false, true, false, true, true, true, true, false, false, true][Math.floor(Math.random()*13)];
                    resolve(successful); 
                    return;
                }
            }
        })(), 10);
    });
}

function failedToLoad() {
    console.log('<red>The kernel has encountered an unexpected error and it <b>wasn\'t able to fix your system</>.');
    console.input('Would you like to try again? [y, n]').then(again => {
        if(again.toLowerCase() === 'y')
            loadDisk().then(loaded => {
                if(loaded)
                    console.log('<green>Kernel fixed, exiting shell.');
                else 
                    failedToLoad();
            });
        else
            console.log('<red><b>System not fixed, exiting shell...');
    });
}

(async() => {
    await console.print('<red><b>Kernel panic, system crash.');
    const ask = async() => {
        await console.print('Please insert the system recovery floppy disk into your computer...');
        const inserted = await console.input('Did you insert the floppy disk? [y, n]');
        if(inserted.toLowerCase() === 'y')
            loadDisk().then(loaded => {
                if(loaded)
                    console.log('<green>Kernel fixed, exiting shell.');
                else 
                    failedToLoad();
            });
        else
            ask(); 
    }
    ask();
})();
